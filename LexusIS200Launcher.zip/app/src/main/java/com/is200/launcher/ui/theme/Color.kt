package com.is200.launcher.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

val BackgroundColor = Color(0xFF050505)
val SurfaceColor = Color(0xFF101010)
val SurfaceLight = Color(0xFF181818)

val AccentColor = Color(0xFF7CC7FF)
val AccentGlow = Color(0xFF4FC3FF)

val BorderColor = Color(0xFF99877D)
val BorderGlow = Color(0xFFB7A79C)